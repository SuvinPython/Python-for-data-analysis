from django.db import models

class Search(models.Model):
    X1 = models.CharField(max_length=200,null=True)
    X4 = models.CharField(max_length=200,null=True)
    X5 = models.CharField(max_length=200,null=True)
    X13 = models.CharField(max_length=200,null=True)
    X21 = models.CharField(max_length=200,null=True)
    X27 = models.CharField(max_length=200,null=True)
    X28 = models.CharField(max_length=200,null=True)
    X37 = models.CharField(max_length=200,null=True)
    X45 = models.CharField(max_length=200,null=True)
    X57 = models.CharField(max_length=200,null=True)



    def __str__(self):
        return self.X1,self.X4,self.X5,self.X13,self.X21,self.X27,self.X28,self.X37,self.X45,self.X57
        
        