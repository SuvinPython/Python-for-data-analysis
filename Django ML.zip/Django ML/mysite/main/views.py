from django.shortcuts import render
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from django.http import HttpResponse
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier




# Create your views here.
def index(request):  
    year1 = pd.read_csv('C:/Users/Suvin/Desktop/Django ML/1year.txt', sep=",", names = list(map( lambda x: f'X{x+2}' ,range(-1,64))))
    year1= year1.replace("?", np.nan)
    year1 = year1.astype(float)

    missing = year1.isna().sum() / year1.shape[0] * 100.00
    missing_df = pd.DataFrame({'column_name': year1.columns,
                                 '%missing': missing})
    missing_df.sort_values('%missing', inplace=True, ascending=False)
    missing_df.head()

    year1 = year1.apply(lambda x: x.fillna(x.mean()),axis=0)
    corr_features1 = correlation(year1, 0.28)
    year1.drop(corr_features1,axis=1, inplace=True)
    X = year1.iloc[: ,:-1]
    Y = year1.iloc[:,-1]
    X_train, X_test, Y_train, Y_test = train_test_split(X,Y,test_size=0.0001)

    rf = RandomForestClassifier(n_estimators = 5, criterion = 'entropy')
    rf.fit(X_train,Y_train)
    X1 = request.POST.get("X1")
    X4 = request.POST.get("X4")
    X5 = request.POST.get("X5")
    X13 = request.POST.get("X13")
    X21 = request.POST.get("X21")
    X27 = request.POST.get("X27")
    X28 = request.POST.get("X28")
    X37 = request.POST.get("X37")
    X45 = request.POST.get("X45")
    X57= request.POST.get("X57")
    
    if(X1==None):
        a = "See here if your company is going well or not"
        context={'y_pred':a}
        return render(request,'index.html',context)

    else :
        X1 = np.float64(X1)
        X4 = np.float64(X4)
        X5 = np.float64(X5)
        X13 = np.float64(X13)
        X21 = np.float64(X21)
        X27 = np.float64(X27)
        X28 = np.float64(X28)
        X37 = np.float64(X37)
        X45 = np.float64(X45)
        X57= np.float64(X57)

        X_test.append({"X1":X1,"X4":X4,"X5":X5,
        "X13":X13,"X21":X21,"X27":X27,"X28":X28,"X37":X37,
        "X45":X45,"X57":X57},ignore_index=True)    
        X_test.fillna(X_test.mean())
        y_pred=rf.predict(X_test)
        if( y_pred[-1]==0):
            a = "Your company is going well"
            context={'y_pred':a}
        else:
            a="Your company is going to bankrupt"
            context={'y_pred':a}
        print(y_pred[-1])
        print(X_test)


        return render(request,'index.html',context)



 


def correlation(dataset, threshold):
    col_corr = set()  # Set of all the names of correlated columns
    corr_matrix = dataset.corr()
    for i in range(len(corr_matrix.columns)):
        for j in range(i):
            if abs(corr_matrix.iloc[i, j]) > threshold: # we are interested in absolute coeff value
                colname = corr_matrix.columns[i]  # getting the name of column
                col_corr.add(colname)
    return col_corr

    


def apropos(request):
    return render(request,'apropos.html')


def contact(request):
    if request.method =="POST":
        message_name = request.POST.get['message-name']
        message_email = request.POST.get['message-email']
        message = request.POST.get['message']
        print(message)
        return render(request,'contact.html')
    else:
        return render(request,'contact.html')